"""Common shop views"""
