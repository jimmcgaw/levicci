import django.dispatch

satchmo_registration = django.dispatch.Signal()
satchmo_registration_verified = django.dispatch.Signal()
satchmo_registration_initialdata = django.dispatch.Signal()
