import satchmo.shipping.config
